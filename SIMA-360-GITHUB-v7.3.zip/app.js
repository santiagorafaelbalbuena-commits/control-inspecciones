import { createClient } from "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm";

const SUPABASE_URL = "https://afijjkklautapdqldmbs.supabase.co";
const SUPABASE_KEY = "sb_publishable_glH8U1OaefjP1GRVERMOCQ_c_FzfFwQ";
const VERIFY_FUNCTION = `${SUPABASE_URL}/functions/v1/verify-commerce`;
const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

const app = document.getElementById("app");
let session = null;
let profile = null;
let route = "dashboard";
let scanner = null;
let pendingWorkToken = null;
let pendingCommerceToken = null;
let authRecovery = false;
let profilePhotoUrl = "";

const esc = (s="") => String(s ?? "").replace(/[&<>"']/g, m => ({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[m]));
const fmtDate = s => s ? new Date(s).toLocaleString("es-AR") : "—";
const fmtDay = s => s ? new Date(`${s}T12:00:00`).toLocaleDateString("es-AR") : "—";
const field = id => document.getElementById(id);
const val = id => field(id)?.value?.trim() ?? "";
const badgeClass = s => String(s || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-z0-9]+/g,"-");
const badge = s => `<span class="status ${badgeClass(s)}">${esc(s || "—")}</span>`;
const emptyRow = (n, text="Todavía no hay registros.") => `<tr><td colspan="${n}" class="empty">${esc(text)}</td></tr>`;

const initials = name => String(name||"").trim().split(/\s+/).slice(0,2).map(x=>x[0]||"").join("").toUpperCase() || "US";

async function getInspectorPhotoUrl(path){
  if(!path) return "";
  try{
    const {data,error}=await supabase.storage.from("inspector-avatars").createSignedUrl(path,43200);
    return error ? "" : (data?.signedUrl || "");
  }catch{return "";}
}

async function refreshOwnPhoto(){
  try{ profilePhotoUrl = profile?.photo_path ? await getInspectorPhotoUrl(profile.photo_path) : ""; }
  catch{ profilePhotoUrl = ""; }
}

async function getProfile(userId){
  const {data,error} = await supabase.from("profiles").select("*").eq("id",userId).single();
  if(error) throw error;
  return data;
}

function toast(message,type="success"){
  document.querySelector(".toast")?.remove();
  const el=document.createElement("div");
  el.className=`toast ${type}`;
  el.textContent=message;
  document.body.appendChild(el);
  setTimeout(()=>el.remove(),3200);
}

async function init(){
  const qs=new URLSearchParams(location.search);
  const verify=qs.get("verify");
  pendingWorkToken=qs.get("work");
  pendingCommerceToken=qs.get("commerce");
  if(verify){ await renderVerification(verify); return; }
  const {data}=await supabase.auth.getSession();
  session=data.session;
  const hashParams=new URLSearchParams(location.hash.replace(/^#/,""));
  if(hashParams.get("type")==="recovery") authRecovery=true;
  if(authRecovery&&session){ recoveryView(); return; }
  if(session){
    try{
      profile=await getProfile(session.user.id);
      await refreshOwnPhoto();
      if(!profile.active){ await supabase.auth.signOut(); session=null; profile=null; }
    }catch{ session=null; profile=null; }
  }
  route=profile?.role==="inspector" ? (pendingWorkToken||pendingCommerceToken ? "nueva-inspeccion" : "inspector-home") : "dashboard";
  render();
}

function loginView(msg="",mode="login"){
  const isRegister=mode==="register";
  const isForgot=mode==="forgot";
  app.innerHTML=`
  <section class="login-page">
    <div class="login-ribbon ribbon-top"></div>
    <div class="login-ribbon ribbon-bottom"></div>
    <div class="login-hero">
      <div class="brand-mark">
        <div class="brand-icon">🏛</div>
        <div><b>Municipalidad</b><span>Santo Tomé · Corrientes</span></div>
      </div>
      <div class="hero-kicker">GESTIÓN MUNICIPAL INTELIGENTE</div>
      <h1>SIMA <span>360°</span></h1>
      <h2>Sistema Integral Municipal de Autogestión, Prevención y Control Inteligente</h2>
      <p>Comercios más seguros, controles más ágiles y datos confiables para una gestión municipal moderna.</p>
      <div class="hero-features">
        <div><b class="feature-icon green">🏪</b><span>Registro de comercios<small>Base municipal unificada</small></span></div>
        <div><b class="feature-icon blue">▣</b><span>Identificación con QR<small>Acceso rápido y seguro</small></span></div>
        <div><b class="feature-icon orange">📋</b><span>Inspecciones digitales<small>Actas, fotos y ubicación</small></span></div>
        <div><b class="feature-icon purple">📊</b><span>Información en tiempo real<small>Reportes y seguimiento</small></span></div>
      </div>
      <div class="login-footline"><span>🛡</span><b>Prevención</b><i>•</i><b>Control</b><i>•</i><b>Compromiso</b></div>
    </div>
    <div class="login-card">
      <div class="login-card-head">
        <div class="login-logo">SIMA <span>360°</span></div>
        <div class="city-tag">Santo Tomé, Corrientes</div>
      </div>
      ${isRegister?`<h2>Crear cuenta</h2><p class="sub">Registro de inspector. La cuenta quedará pendiente de habilitación por un Administrador.</p>`:isForgot?`<h2>Recuperar contraseña</h2><p class="sub">Ingresá tu correo y te enviaremos un enlace para crear una nueva contraseña.</p>`:`<h2>Bienvenido</h2><p class="sub">Ingresá con tu correo electrónico.</p>`}
      ${msg?`<div class="${msg.startsWith("✓")?"success":"error"}">${esc(msg.replace(/^✓\s*/,""))}</div>`:""}
      ${isRegister?`
        <form id="registerForm">
          <div class="field icon-field"><label>Nombre y apellido</label><div class="input-wrap"><span>👤</span><input id="rname" autocomplete="name" required></div></div>
          <div class="field icon-field"><label>Correo electrónico</label><div class="input-wrap"><span>✉</span><input id="remail" type="email" autocomplete="email" required></div></div>
          <div class="field icon-field"><label>Contraseña</label><div class="input-wrap"><span>🔒</span><input id="rpassword" type="password" minlength="6" autocomplete="new-password" required></div></div>
          <div class="field icon-field"><label>Repetir contraseña</label><div class="input-wrap"><span>🔒</span><input id="rpassword2" type="password" minlength="6" autocomplete="new-password" required></div></div>
          <button class="primary full login-submit" type="submit">Registrarme <span>→</span></button>
        </form>
        <div class="auth-links"><button type="button" id="backLogin1">← Volver a iniciar sesión</button></div>
      `:isForgot?`
        <form id="forgotForm">
          <div class="field icon-field"><label>Correo electrónico</label><div class="input-wrap"><span>✉</span><input id="femail" type="email" autocomplete="email" required></div></div>
          <button class="primary full login-submit" type="submit">Enviar enlace <span>→</span></button>
        </form>
        <div class="auth-links"><button type="button" id="backLogin2">← Volver a iniciar sesión</button></div>
      `:`
        <form id="loginForm">
          <div class="field icon-field"><label>Correo electrónico</label><div class="input-wrap"><span>✉</span><input id="email" type="email" autocomplete="username" required></div></div>
          <div class="field icon-field"><label>Contraseña</label><div class="input-wrap"><span>🔒</span><input id="password" type="password" autocomplete="current-password" required><button type="button" class="eye-btn" id="togglePassword" aria-label="Mostrar contraseña">◉</button></div></div>
          <button class="primary full login-submit" type="submit">Iniciar sesión <span>→</span></button>
        </form>
        <div class="quick-access-title"><span></span><b>perfiles de acceso</b><span></span></div>
        <div class="role-cards"><button type="button" data-rolehint="Administrador"><b>👥</b><strong>Soy Administrador</strong><small>Gestión completa</small></button><button type="button" data-rolehint="Inspector"><b>👷</b><strong>Soy Inspector</strong><small>Realizar inspecciones</small></button></div>
        <div class="help centered">El sistema reconoce automáticamente tu perfil al iniciar sesión.</div>
      `}
    </div>
  </section>`;

  if(isRegister){
    field("backLogin1").onclick=()=>loginView();
    field("registerForm").onsubmit=async e=>{
      e.preventDefault();
      const pass=field("rpassword").value,pass2=field("rpassword2").value;
      if(pass!==pass2)return loginView("Las contraseñas no coinciden.","register");
      const {data,error}=await supabase.auth.signUp({
        email:val("remail").toLowerCase(),
        password:pass,
        options:{data:{full_name:val("rname")},emailRedirectTo:`${location.origin}${location.pathname}`}
      });
      if(error)return loginView(error.message,"register");
      if(data.session)await supabase.auth.signOut();
      return loginView("✓ Registro enviado. Revisá tu correo si te pide confirmar la cuenta. Luego un Administrador deberá habilitarte.");
    };
    return;
  }
  if(isForgot){
    field("backLogin2").onclick=()=>loginView();
    field("forgotForm").onsubmit=async e=>{
      e.preventDefault();
      const {error}=await supabase.auth.resetPasswordForEmail(val("femail").toLowerCase(),{redirectTo:`${location.origin}${location.pathname}`});
      if(error)return loginView(error.message,"forgot");
      return loginView("✓ Te enviamos un correo para restablecer la contraseña. Revisá también la carpeta Spam.");
    };
    return;
  }

  field("togglePassword").onclick=()=>{const i=field("password");i.type=i.type==="password"?"text":"password";field("togglePassword").textContent=i.type==="password"?"◉":"◎"};
  document.querySelectorAll("[data-rolehint]").forEach(b=>b.onclick=()=>{document.querySelectorAll("[data-rolehint]").forEach(x=>x.classList.remove("selected"));b.classList.add("selected");field("email")?.focus()});
  field("loginForm").onsubmit=async e=>{
    e.preventDefault();
    const {data,error}=await supabase.auth.signInWithPassword({email:val("email"),password:field("password").value});
    if(error) return loginView("Correo o contraseña incorrectos.");
    session=data.session;
    try{
      profile=await getProfile(session.user.id);
      if(!profile.active){ await supabase.auth.signOut();session=null;profile=null;return loginView("Este usuario todavía no está habilitado por un Administrador."); }
      await refreshOwnPhoto();
      route=profile.role==="admin"?"dashboard":(pendingWorkToken||pendingCommerceToken?"nueva-inspeccion":"inspector-home");
      render();
    }catch(err){
      console.error(err);
      loginView("No se pudo cargar el perfil del usuario. Actualizá la página e intentá nuevamente.");
    }
  };
}

function recoveryView(msg=""){
  app.innerHTML=`<section class="login-page recovery-page"><div class="login-ribbon ribbon-top"></div><div class="login-ribbon ribbon-bottom"></div><div class="login-card recovery-card"><div class="login-logo">SIMA <span>360°</span></div><h2>Nueva contraseña</h2><p class="sub">Elegí una contraseña nueva para tu cuenta.</p>${msg?`<div class="error">${esc(msg)}</div>`:""}<form id="recoveryForm"><div class="field icon-field"><label>Nueva contraseña</label><div class="input-wrap"><span>🔒</span><input id="newpass" type="password" minlength="6" required></div></div><div class="field icon-field"><label>Repetir contraseña</label><div class="input-wrap"><span>🔒</span><input id="newpass2" type="password" minlength="6" required></div></div><button class="primary full login-submit">Guardar contraseña <span>→</span></button></form></div></section>`;
  field("recoveryForm").onsubmit=async e=>{e.preventDefault();const p1=field("newpass").value,p2=field("newpass2").value;if(p1!==p2)return recoveryView("Las contraseñas no coinciden.");const {error}=await supabase.auth.updateUser({password:p1});if(error)return recoveryView(error.message);authRecovery=false;await supabase.auth.signOut();session=null;profile=null;history.replaceState({},"",location.pathname);loginView("✓ Contraseña actualizada. Ya podés iniciar sesión.")};
}

function shell(inner){
  const admin=profile?.role==="admin";
  const navs=admin?[
    ["dashboard","IN","Inicio"],["comercios","CO","Comercios"],["obras","OB","Obras privadas"],["inspecciones","IS","Inspecciones"],
    ["contribuyentes","CT","Contribuyentes"],["infracciones","IF","Infracciones"],["inspectores","US","Usuarios"],["planilla","PL","Planilla Excel"],["reportes","RP","Reportes"]
  ]:[
    ["inspector-home","IN","Inicio"],["planilla","PL","Planilla comercios"],["escanear","QR","Escanear QR"],["nueva-inspeccion","NI","Nueva inspección"],["mis-inspecciones","MI","Mis inspecciones"]
  ];
  app.innerHTML=`
  <div class="app-shell route-${route}">
    <header class="topbar"><div class="top-left"><button id="mobileMenu" class="mobile-menu-btn" type="button" aria-label="Abrir menú">☰</button><div class="mini-logo">360°</div><div><div class="top-title">SIMA 360°</div><div class="top-sub">Gestión Municipal · Santo Tomé</div></div></div>
      <div class="userbox"><div class="top-avatar">${profilePhotoUrl?`<img src="${profilePhotoUrl}" alt="Foto de ${esc(profile?.full_name)}">`:`<span>${initials(profile?.full_name)}</span>`}</div><span class="role-badge">${admin?"Administrador":"Inspector"}</span><strong>${esc(profile?.full_name)}</strong><button id="logout" class="ghost small-btn">Salir</button></div></header>
    <div id="mobileOverlay" class="mobile-nav-overlay"></div>
    <div class="layout"><aside id="mainSidebar" class="sidebar"><div class="sidebar-label">MENÚ PRINCIPAL</div>${navs.map(n=>`<button class="navbtn ${route===n[0]?"active":""}" data-route="${n[0]}"><span>${n[1]}</span>${n[2]}</button>`).join("")}<div class="sidebar-brand"><b>SIMA 360°</b><span>Datos confiables para mejores decisiones.</span></div></aside>
      <section class="content">${inner}<div class="footer-note">SIMA 360° · Sistema Integral Municipal · Supabase conectado</div></section></div>
  </div>`;
  const sidebar=field("mainSidebar"),overlay=field("mobileOverlay");
  const closeMobileMenu=()=>{sidebar?.classList.remove("mobile-open");overlay?.classList.remove("show")};
  field("mobileMenu")?.addEventListener("click",()=>{sidebar?.classList.toggle("mobile-open");overlay?.classList.toggle("show")});
  overlay?.addEventListener("click",closeMobileMenu);
  field("logout").onclick=async()=>{closeMobileMenu();try{if(scanner)await scanner.stop()}catch{}scanner=null;await supabase.auth.signOut();session=null;profile=null;profilePhotoUrl="";route="dashboard";render()};
  document.querySelectorAll("[data-route]").forEach(b=>b.onclick=async()=>{closeMobileMenu();try{if(scanner)await scanner.stop()}catch{}scanner=null;route=b.dataset.route;render()});
}

function loading(text="Cargando información..."){ shell(`<div class="loading"><div class="spinner"></div><strong>${esc(text)}</strong></div>`); }
function pageTitle(title,sub,action=""){return `<div class="page-title"><div><h1>${esc(title)}</h1><p>${esc(sub)}</p></div>${action}</div>`}
function metric(icon,label,value,color="blue",note="",target=""){return `<button class="metric-card ${color}${target?` metric-link`:``}" ${target?`data-jump="${target}"`:``} type="button"><div class="metric-icon">${icon}</div><div><div class="metric-label">${esc(label)}</div><div class="metric">${value??0}</div>${note?`<div class="metric-note">${esc(note)}</div>`:""}</div></button>`}

async function dashboard(){
  loading("Preparando panel municipal...");
  const [comQ,workQ,inspQ,conQ,infQ,userQ,lastQ]=await Promise.all([
    supabase.from("commerces").select("id",{count:"exact",head:true}),
    supabase.from("works").select("id",{count:"exact",head:true}),
    supabase.from("inspections").select("id",{count:"exact",head:true}),
    supabase.from("contributors").select("id",{count:"exact",head:true}),
    supabase.from("infractions").select("id",{count:"exact",head:true}).eq("status","abierta"),
    supabase.from("profiles").select("id",{count:"exact",head:true}).eq("role","inspector").eq("active",true),
    supabase.from("inspections").select("id,inspected_at,status,target_type,act_number,commerces(business_name),works(responsible,address),profiles!inspections_inspector_id_fkey(full_name)").order("inspected_at",{ascending:false}).limit(6)
  ]);
  const last=lastQ.data||[];
  shell(`<div class="dashboard-banner"><div><span class="dashboard-eyebrow">CENTRO DE GESTIÓN MUNICIPAL</span><h2>Todo el municipio, en una sola vista</h2><p>Seguimiento operativo, control de inspecciones y datos clave para tomar decisiones.</p></div><div class="dashboard-live"><span class="live-dot"></span> Sistema conectado</div></div>${pageTitle("Panel de administración","Resumen general y estado actual del municipio.",`<button class="secondary excel-export-btn" id="dashboardExcel" type="button">⬇ Exportar Excel</button>`)}
    <div class="metrics-grid">${metric("CO","Comercios",comQ.count,"blue","","comercios")}${metric("OB","Obras privadas",workQ.count,"orange","","obras")}${metric("IS","Inspecciones",inspQ.count,"green","","inspecciones")}${metric("CT","Contribuyentes",conQ.count,"purple","","contribuyentes")}${metric("IF","Infracciones abiertas",infQ.count,"red","","infracciones")}${metric("US","Inspectores activos",userQ.count,"cyan","","inspectores")}</div>
    <div class="section-intro"><h3>Accesos rápidos por sector</h3><p>Ahora podés ingresar a cada módulo directamente desde este panel, sin depender solo del menú lateral.</p></div>
    <div class="quick-grid admin-sectors"><button data-jump="comercios"><span>CO</span><b>Comercios</b><small>Registro y habilitación</small></button><button data-jump="obras"><span>OB</span><b>Obras privadas</b><small>Seguimiento de obras</small></button><button data-jump="inspecciones"><span>IS</span><b>Inspecciones</b><small>Historial y control</small></button><button data-jump="contribuyentes"><span>CT</span><b>Contribuyentes</b><small>Datos y responsables</small></button><button data-jump="infracciones"><span>IF</span><b>Infracciones</b><small>Alertas y seguimiento</small></button><button data-jump="inspectores"><span>US</span><b>Usuarios</b><small>Inspectores activos</small></button><button data-jump="planilla"><span>PL</span><b>Planilla Excel</b><small>Comercios e inspecciones</small></button><button data-jump="reportes"><span>RP</span><b>Reportes</b><small>Indicadores y gráficos</small></button></div>
    <div class="panel"><div class="panel-head"><h3>Últimas inspecciones</h3><span>Actualización en tiempo real</span></div>${inspectionTable(last)}</div>`);
  document.querySelectorAll("[data-jump]").forEach(b=>b.onclick=()=>{route=b.dataset.jump;render()});
  wireExcelButton("dashboardExcel");
}

function showQr(token,name,type="commerce"){
  const url=type==="commerce"?`${location.origin}${location.pathname}?verify=${token}`:`${location.origin}${location.pathname}?work=${token}`;
  const modal=document.createElement("div");modal.className="qr-modal";
  modal.innerHTML=`<div class="qr-modal-card"><h3>QR · ${esc(name)}</h3><div id="qrRender" class="qr-canvas"></div><div class="small wrap">${esc(url)}</div><div class="actions top-gap"><button class="ghost" id="closeQr">Cerrar</button></div></div>`;
  document.body.appendChild(modal);
  new window.QRCode(field("qrRender"),{text:url,width:220,height:220});
  field("closeQr").onclick=()=>modal.remove();
}

async function commercesView(){
  const [{data,error},{data:contributors}]=await Promise.all([
    supabase.from("commerces").select("*,contributors(name)").order("business_name"),
    supabase.from("contributors").select("id,name").eq("status","activo").order("name")
  ]);
  if(error)return shell(`<div class="error">${esc(error.message)}</div>`);
  shell(`${pageTitle("Comercios","Registro unificado, habilitaciones y códigos QR.",`<button class="primary" id="addCommerce">+ Nuevo comercio</button>`)}<div id="formZone"></div>
    <div class="panel"><div class="table-wrap"><table><thead><tr><th>Comercio</th><th>Rubro / zona</th><th>Dirección</th><th>Habilitación</th><th>Estado</th><th>QR</th></tr></thead><tbody>
    ${(data||[]).map(c=>`<tr><td><b>${esc(c.business_name)}</b><div class="small">${esc(c.cuit||c.legal_name||"")}</div></td><td>${esc(c.sector||"—")}<div class="small">${esc(c.zone||"")}</div></td><td>${esc(c.address)}</td><td>${esc(c.commercial_license||"—")}<div class="small">${c.license_expiration?`Vence ${fmtDay(c.license_expiration)}`:""}</div></td><td>${badge(c.status|| (c.active?"activo":"inactivo"))}</td><td><button class="secondary" data-qr="${c.qr_token}" data-name="${esc(c.business_name)}">Ver QR</button></td></tr>`).join("")||emptyRow(6)}</tbody></table></div></div>`);
  field("addCommerce").onclick=()=>{
    field("formZone").innerHTML=`<div class="panel form-panel"><h3>Nuevo comercio</h3><form id="commerceForm" class="form-grid">
      <div class="field"><label>Nombre comercial *</label><input id="business_name" required></div><div class="field"><label>Razón social</label><input id="legal_name"></div>
      <div class="field"><label>CUIT</label><input id="cuit"></div><div class="field"><label>N° habilitación</label><input id="license"></div>
      <div class="field"><label>Rubro</label><input id="sector" placeholder="Ej.: Gastronomía"></div><div class="field"><label>Zona</label><input id="zone"></div>
      <div class="field"><label>Teléfono</label><input id="phone"></div><div class="field"><label>Correo</label><input id="cemail" type="email"></div>
      <div class="field"><label>Vencimiento habilitación</label><input id="license_expiration" type="date"></div><div class="field"><label>Contribuyente</label><select id="contributor_id"><option value="">Sin vincular</option>${(contributors||[]).map(x=>`<option value="${x.id}">${esc(x.name)}</option>`).join("")}</select></div>
      <div class="field wide"><label>Dirección *</label><input id="address" required></div><div class="field wide"><label>Observaciones</label><textarea id="cobs" rows="3"></textarea></div>
      <div class="wide actions"><button class="primary">Guardar comercio</button><button class="ghost" type="button" id="cancelForm">Cancelar</button></div></form></div>`;
    field("cancelForm").onclick=()=>field("formZone").innerHTML="";
    field("commerceForm").onsubmit=async e=>{e.preventDefault();const payload={business_name:val("business_name"),legal_name:val("legal_name")||null,cuit:val("cuit")||null,commercial_license:val("license")||null,address:val("address"),city:"Santo Tomé",province:"Corrientes",sector:val("sector")||null,zone:val("zone")||null,phone:val("phone")||null,email:val("cemail")||null,license_expiration:val("license_expiration")||null,contributor_id:val("contributor_id")||null,observations:val("cobs")||null,status:"activo",active:true,created_by:session.user.id};const {error}=await supabase.from("commerces").insert(payload);if(error)return toast(error.message,"error");toast("Comercio registrado.");commercesView()};
  };
  document.querySelectorAll("[data-qr]").forEach(b=>b.onclick=()=>showQr(b.dataset.qr,b.dataset.name,"commerce"));
}

async function worksView(){
  const [{data,error},{data:contributors}]=await Promise.all([supabase.from("works").select("*,contributors(name)").order("created_at",{ascending:false}),supabase.from("contributors").select("id,name").eq("status","activo").order("name")]);
  if(error)return shell(`<div class="error">${esc(error.message)}</div>`);
  shell(`${pageTitle("Obras privadas","Registro, inspecciones y seguimiento del estado de cada obra.",`<button class="primary" id="addWork">+ Nueva obra</button>`)}<div id="formZone"></div><div class="panel"><div class="table-wrap"><table><thead><tr><th>Responsable</th><th>Ubicación</th><th>Expediente</th><th>Estado</th><th>Fechas</th><th>QR</th></tr></thead><tbody>
  ${(data||[]).map(w=>`<tr><td><b>${esc(w.responsible)}</b><div class="small">${esc(w.dni_cuit||"")}</div></td><td>${esc(w.address)}<div class="small">${esc(w.zone||"")}</div></td><td>${esc(w.file_number||"—")}</td><td>${badge(w.status)}</td><td>${w.start_date?fmtDay(w.start_date):"—"}<div class="small">${w.estimated_end_date?`Fin estimado ${fmtDay(w.estimated_end_date)}`:""}</div></td><td><button class="secondary" data-workqr="${w.qr_token}" data-name="${esc(w.responsible)}">Ver QR</button></td></tr>`).join("")||emptyRow(6)}</tbody></table></div></div>`);
  field("addWork").onclick=()=>{field("formZone").innerHTML=`<div class="panel form-panel"><h3>Nueva obra privada</h3><form id="workForm" class="form-grid">
    <div class="field"><label>Responsable *</label><input id="responsible" required></div><div class="field"><label>DNI / CUIT</label><input id="wdni"></div><div class="field"><label>N° expediente</label><input id="file_number"></div><div class="field"><label>Zona</label><input id="wzone"></div>
    <div class="field"><label>Fecha de inicio</label><input id="start_date" type="date"></div><div class="field"><label>Fin estimado</label><input id="estimated_end_date" type="date"></div><div class="field"><label>Estado</label><select id="wstatus"><option value="inicio">En inicio</option><option value="en_ejecucion">En ejecución</option><option value="observada">Observada</option><option value="paralizada">Paralizada</option><option value="finalizada">Finalizada</option></select></div><div class="field"><label>Contribuyente</label><select id="wcontributor"><option value="">Sin vincular</option>${(contributors||[]).map(x=>`<option value="${x.id}">${esc(x.name)}</option>`).join("")}</select></div>
    <div class="field wide"><label>Dirección *</label><input id="waddress" required></div><div class="field wide"><label>Descripción</label><textarea id="wdescription" rows="3"></textarea></div><div class="field wide"><label>Observaciones</label><textarea id="wobs" rows="3"></textarea></div>
    <div class="wide actions"><button class="primary">Guardar obra</button><button class="ghost" type="button" id="cancelForm">Cancelar</button></div></form></div>`;
    field("cancelForm").onclick=()=>field("formZone").innerHTML="";
    field("workForm").onsubmit=async e=>{e.preventDefault();const payload={responsible:val("responsible"),dni_cuit:val("wdni")||null,address:val("waddress"),city:"Santo Tomé",province:"Corrientes",zone:val("wzone")||null,file_number:val("file_number")||null,description:val("wdescription")||null,status:val("wstatus"),start_date:val("start_date")||null,estimated_end_date:val("estimated_end_date")||null,observations:val("wobs")||null,contributor_id:val("wcontributor")||null,created_by:session.user.id};const {error}=await supabase.from("works").insert(payload);if(error)return toast(error.message,"error");toast("Obra registrada.");worksView()};
  };
  document.querySelectorAll("[data-workqr]").forEach(b=>b.onclick=()=>showQr(b.dataset.workqr,b.dataset.name,"work"));
}

async function contributorsView(){
  const {data,error}=await supabase.from("contributors").select("*").order("name");
  if(error)return shell(`<div class="error">${esc(error.message)}</div>`);
  shell(`${pageTitle("Contribuyentes","Personas y organizaciones vinculadas con comercios y obras.",`<button class="primary" id="addContributor">+ Nuevo contribuyente</button>`)}<div id="formZone"></div><div class="panel"><div class="table-wrap"><table><thead><tr><th>Nombre / razón social</th><th>DNI / CUIT</th><th>Contacto</th><th>Actividad</th><th>Zona</th><th>Estado</th></tr></thead><tbody>${(data||[]).map(c=>`<tr><td><b>${esc(c.name)}</b><div class="small">${esc(c.contributor_type)}</div></td><td>${esc(c.dni_cuit||"—")}</td><td>${esc(c.phone||"—")}<div class="small">${esc(c.email||"")}</div></td><td>${esc(c.activity||"—")}</td><td>${esc(c.zone||"—")}</td><td>${badge(c.status)}</td></tr>`).join("")||emptyRow(6)}</tbody></table></div></div>`);
  field("addContributor").onclick=()=>{field("formZone").innerHTML=`<div class="panel form-panel"><h3>Nuevo contribuyente</h3><form id="contributorForm" class="form-grid"><div class="field"><label>Tipo</label><select id="ctype"><option value="persona">Persona</option><option value="empresa">Empresa</option></select></div><div class="field"><label>Nombre / razón social *</label><input id="cname" required></div><div class="field"><label>DNI / CUIT</label><input id="cdni"></div><div class="field"><label>Actividad</label><input id="cactivity"></div><div class="field"><label>Teléfono</label><input id="cphone"></div><div class="field"><label>Correo</label><input id="cemail" type="email"></div><div class="field"><label>Zona</label><input id="czone"></div><div class="field"><label>Dirección</label><input id="caddress"></div><div class="wide actions"><button class="primary">Guardar contribuyente</button><button class="ghost" type="button" id="cancelForm">Cancelar</button></div></form></div>`;field("cancelForm").onclick=()=>field("formZone").innerHTML="";field("contributorForm").onsubmit=async e=>{e.preventDefault();const payload={contributor_type:val("ctype"),name:val("cname"),dni_cuit:val("cdni")||null,phone:val("cphone")||null,email:val("cemail")||null,address:val("caddress")||null,zone:val("czone")||null,activity:val("cactivity")||null,status:"activo"};const {error}=await supabase.from("contributors").insert(payload);if(error)return toast(error.message,"error");toast("Contribuyente registrado.");contributorsView()};};
}

function inspectionTable(rows){
  if(!rows.length)return `<div class="notice">Todavía no hay inspecciones registradas.</div>`;
  return `<div class="table-wrap"><table><thead><tr><th>Fecha</th><th>Inspeccionado</th><th>Inspector</th><th>Acta</th><th>Resultado</th><th>Observaciones</th></tr></thead><tbody>${rows.map(x=>{const target=x.target_type==="work"?(x.works?`${x.works.responsible} · ${x.works.address}`:"Obra"):(x.commerces?.business_name||"Comercio");return `<tr><td>${fmtDate(x.inspected_at)}</td><td><b>${esc(target)}</b><div class="small">${x.target_type==="work"?"Obra privada":"Comercio"}</div></td><td>${esc(x.profiles?.full_name||profile?.full_name||"—")}</td><td>${esc(x.act_number||"—")}</td><td>${badge(x.status)}</td><td>${esc(x.observations||"")}</td></tr>`}).join("")}</tbody></table></div>`;
}

async function inspectionsView(){
  const {data,error}=await supabase.from("inspections").select("id,inspected_at,status,observations,target_type,act_number,regularization_deadline,commerces(business_name),works(responsible,address),profiles!inspections_inspector_id_fkey(full_name)").order("inspected_at",{ascending:false});
  shell(`${pageTitle("Inspecciones","Historial general de comercios y obras privadas.")}<div class="panel">${error?`<div class="error">${esc(error.message)}</div>`:inspectionTable(data||[])}</div>`);
}

async function infractionsView(){
  const [{data,error},{data:inspections}]=await Promise.all([supabase.from("infractions").select("*,inspections(act_number,target_type,commerces(business_name),works(responsible,address))").order("infraction_date",{ascending:false}),supabase.from("inspections").select("id,act_number,inspected_at,target_type,commerces(business_name),works(responsible,address)").order("inspected_at",{ascending:false}).limit(100)]);
  if(error)return shell(`<div class="error">${esc(error.message)}</div>`);
  shell(`${pageTitle("Infracciones","Observaciones, plazos de regularización y seguimiento.",`<button class="primary" id="addInfraction">+ Nueva infracción</button>`)}<div id="formZone"></div><div class="panel"><div class="table-wrap"><table><thead><tr><th>Código</th><th>Fecha</th><th>Inspección</th><th>Motivo</th><th>Plazo</th><th>Estado</th></tr></thead><tbody>${(data||[]).map(i=>`<tr><td><b>${esc(i.code)}</b></td><td>${fmtDay(i.infraction_date)}</td><td>${esc(i.inspections?.act_number||"—")}</td><td>${esc(i.reason)}<div class="small">${esc(i.regulation||"")}</div></td><td>${fmtDay(i.regularization_deadline)}</td><td>${badge(i.status)}</td></tr>`).join("")||emptyRow(6)}</tbody></table></div></div>`);
  field("addInfraction").onclick=()=>{field("formZone").innerHTML=`<div class="panel form-panel"><h3>Nueva infracción</h3><form id="infractionForm" class="form-grid"><div class="field wide"><label>Inspección *</label><select id="inspection_id" required><option value="">Seleccionar...</option>${(inspections||[]).map(i=>{const t=i.target_type==="work"?(i.works?.responsible||"Obra"):(i.commerces?.business_name||"Comercio");return `<option value="${i.id}">${esc(i.act_number||fmtDate(i.inspected_at))} · ${esc(t)}</option>`}).join("")}</select></div><div class="field wide"><label>Motivo *</label><input id="reason" required></div><div class="field"><label>Normativa</label><input id="regulation"></div><div class="field"><label>Plazo de regularización</label><input id="deadline" type="date"></div><div class="field wide"><label>Observaciones</label><textarea id="iobs" rows="3"></textarea></div><div class="wide actions"><button class="primary">Guardar infracción</button><button class="ghost" type="button" id="cancelForm">Cancelar</button></div></form></div>`;field("cancelForm").onclick=()=>field("formZone").innerHTML="";field("infractionForm").onsubmit=async e=>{e.preventDefault();const payload={inspection_id:val("inspection_id"),reason:val("reason"),regulation:val("regulation")||null,regularization_deadline:val("deadline")||null,observations:val("iobs")||null,status:"abierta"};const {error}=await supabase.from("infractions").insert(payload);if(error)return toast(error.message,"error");toast("Infracción registrada.");infractionsView()};};
}

async function inspectorsView(){
  const {data,error}=await supabase.from("profiles").select("id,full_name,email,role,active,created_at,photo_path").eq("role","inspector").order("full_name");
  if(error)return shell(`<div class="error">${esc(error.message)}</div>`);
  const inspectors=data||[];
  const photoUrls=await Promise.all(inspectors.map(i=>getInspectorPhotoUrl(i.photo_path)));
  shell(`${pageTitle("Usuarios e inspectores","Alta, habilitación, foto y control de acceso.",`<button class="primary" id="addInspector">+ Nuevo inspector</button>`)}<div id="formZone"></div>
    <div class="panel"><div class="table-wrap"><table><thead><tr><th>Foto</th><th>Nombre</th><th>Correo</th><th>Alta</th><th>Estado</th><th>Foto</th><th>Acción</th></tr></thead><tbody>
    ${inspectors.map((i,idx)=>`<tr>
      <td><div class="inspector-avatar">${photoUrls[idx]?`<img src="${photoUrls[idx]}" alt="Foto de ${esc(i.full_name)}">`:`<span>${initials(i.full_name)}</span>`}</div></td>
      <td><b>${esc(i.full_name)}</b></td>
      <td>${esc(i.email)}</td>
      <td>${fmtDate(i.created_at)}</td>
      <td>${badge(i.active?"Activo":"Inactivo")}</td>
      <td>
        <input class="avatar-input" type="file" accept="image/jpeg,image/png,image/webp" data-avatar-input="${i.id}" hidden>
        <button class="secondary" type="button" data-avatar="${i.id}" data-old-path="${esc(i.photo_path||"")}">${i.photo_path?"Cambiar foto":"Subir foto"}</button>
      </td>
      <td><button class="${i.active?"danger":"secondary"}" data-toggle="${i.id}" data-active="${i.active}">${i.active?"Desactivar":"Habilitar"}</button></td>
    </tr>`).join("")||emptyRow(7)}</tbody></table></div></div>`);

  field("addInspector").onclick=()=>{
    field("formZone").innerHTML=`<div class="panel form-panel"><h3>Nuevo inspector</h3><form id="inspectorForm" class="form-grid"><div class="field"><label>Nombre y apellido *</label><input id="iname" required></div><div class="field"><label>Correo *</label><input id="iemail" type="email" required></div><div class="field"><label>Contraseña inicial *</label><input id="ipass" type="password" minlength="6" required></div><div class="wide actions"><button class="primary">Crear inspector</button><button class="ghost" type="button" id="cancelForm">Cancelar</button></div></form></div>`;
    field("cancelForm").onclick=()=>field("formZone").innerHTML="";
    field("inspectorForm").onsubmit=async e=>{
      e.preventDefault();
      const {data,error}=await supabase.functions.invoke("create-inspector",{body:{full_name:val("iname"),email:val("iemail").toLowerCase(),password:field("ipass").value}});
      if(error||data?.error)return toast(data?.error||error.message,"error");
      toast("Inspector creado y habilitado. Ahora podés cargar su foto.");
      inspectorsView()
    };
  };

  document.querySelectorAll("[data-avatar]").forEach(b=>b.onclick=()=>{
    document.querySelector(`[data-avatar-input="${b.dataset.avatar}"]`)?.click();
  });

  document.querySelectorAll("[data-avatar-input]").forEach(input=>input.onchange=async()=>{
    const file=input.files?.[0];
    if(!file)return;
    if(!["image/jpeg","image/png","image/webp"].includes(file.type))return toast("La foto debe ser JPG, PNG o WEBP.","error");
    if(file.size>5*1024*1024)return toast("La foto no puede superar los 5 MB.","error");
    const inspectorId=input.dataset.avatarInput;
    const button=document.querySelector(`[data-avatar="${inspectorId}"]`);
    const oldPath=button?.dataset.oldPath||"";
    const ext=file.type==="image/png"?"png":file.type==="image/webp"?"webp":"jpg";
    const newPath=`${inspectorId}/perfil-${Date.now()}.${ext}`;
    const upload=await supabase.storage.from("inspector-avatars").upload(newPath,file,{upsert:false,contentType:file.type});
    if(upload.error)return toast(upload.error.message,"error");
    const updated=await supabase.from("profiles").update({photo_path:newPath}).eq("id",inspectorId);
    if(updated.error){
      await supabase.storage.from("inspector-avatars").remove([newPath]);
      return toast(updated.error.message,"error");
    }
    if(oldPath)await supabase.storage.from("inspector-avatars").remove([oldPath]);
    toast("Foto del inspector actualizada.");
    inspectorsView();
  });

  document.querySelectorAll("[data-toggle]").forEach(b=>b.onclick=async()=>{
    const active=b.dataset.active==="true";
    const {error}=await supabase.from("profiles").update({active:!active}).eq("id",b.dataset.toggle);
    if(error)return toast(error.message,"error");
    inspectorsView()
  });
}


function excelSafe(value){
  if(value===null||value===undefined)return "";
  if(typeof value==="boolean")return value?"Sí":"No";
  return String(value);
}

function excelStatusLabel(value){
  return String(value||"Sin dato").replaceAll("_"," ").replace(/\b\w/g,m=>m.toUpperCase());
}

function makeBarChartImage(title,obj,color="#1597e5"){
  const entries=Object.entries(obj||{}).sort((a,b)=>b[1]-a[1]);
  const canvas=document.createElement("canvas");
  canvas.width=1200;
  canvas.height=Math.max(430,170+Math.max(1,entries.length)*62);
  const ctx=canvas.getContext("2d");
  ctx.fillStyle="#ffffff";ctx.fillRect(0,0,canvas.width,canvas.height);
  ctx.fillStyle="#102c49";ctx.font="bold 34px Arial";ctx.fillText(title,55,58);
  ctx.fillStyle="#667085";ctx.font="20px Arial";ctx.fillText("SIMA 360° · Reporte municipal",55,92);
  if(!entries.length){ctx.fillStyle="#98a2b3";ctx.font="26px Arial";ctx.fillText("Sin datos disponibles",55,165);return canvas.toDataURL("image/png");}
  const max=Math.max(1,...entries.map(x=>Number(x[1])||0));
  const left=330,top=145,barW=720,rowH=62;
  entries.forEach(([label,val],i)=>{
    const y=top+i*rowH;
    ctx.fillStyle="#344054";ctx.font="20px Arial";
    const clean=excelStatusLabel(label);
    ctx.fillText(clean.length>24?clean.slice(0,22)+"…":clean,55,y+25);
    ctx.fillStyle="#eef2f6";ctx.fillRect(left,y,barW,30);
    ctx.fillStyle=color;ctx.fillRect(left,y,Math.max(4,barW*(Number(val)||0)/max),30);
    ctx.fillStyle="#101828";ctx.font="bold 20px Arial";ctx.fillText(String(val),left+barW+28,y+23);
  });
  return canvas.toDataURL("image/png");
}

function styleExcelHeader(row,color="FF102C49"){
  row.height=23;
  row.eachCell(cell=>{
    cell.font={bold:true,color:{argb:"FFFFFFFF"}};
    cell.fill={type:"pattern",pattern:"solid",fgColor:{argb:color}};
    cell.alignment={vertical:"middle",horizontal:"left",wrapText:true};
    cell.border={bottom:{style:"thin",color:{argb:"FFD0D5DD"}}};
  });
}

function addExcelDataSheet(workbook,name,title,headers,rows,color="FF102C49",widths=[]){
  const ws=workbook.addWorksheet(name,{views:[{state:"frozen",ySplit:4}]});
  ws.mergeCells(1,1,1,headers.length);
  const titleCell=ws.getCell(1,1);titleCell.value=title;titleCell.font={bold:true,size:18,color:{argb:"FFFFFFFF"}};titleCell.fill={type:"pattern",pattern:"solid",fgColor:{argb:color}};titleCell.alignment={vertical:"middle"};ws.getRow(1).height=30;
  ws.mergeCells(2,1,2,headers.length);ws.getCell(2,1).value=`Generado por SIMA 360° · ${new Date().toLocaleString("es-AR")}`;ws.getCell(2,1).font={italic:true,color:{argb:"FF667085"}};
  const hr=ws.getRow(4);headers.forEach((h,i)=>hr.getCell(i+1).value=h);styleExcelHeader(hr,color);
  rows.forEach(values=>ws.addRow(values));
  if(rows.length){
    const dataRange=ws.getRows(5,rows.length)||[];
    dataRange.forEach((r,ri)=>{r.eachCell(c=>{c.alignment={vertical:"top",wrapText:true};if(ri%2===1)c.fill={type:"pattern",pattern:"solid",fgColor:{argb:"FFF8FAFC"}};});});
  }
  ws.autoFilter={from:{row:4,column:1},to:{row:4,column:headers.length}};
  headers.forEach((_,i)=>{ws.getColumn(i+1).width=widths[i]||18;});
  return ws;
}

async function exportMunicipalExcel(triggerButton=null){
  if(profile?.role!=="admin")return toast("Solo el Administrador puede exportar reportes.","error");
  if(!window.ExcelJS)return toast("No se pudo cargar el módulo de Excel. Revisá la conexión e intentá nuevamente.","error");
  const oldText=triggerButton?.textContent;
  if(triggerButton){triggerButton.disabled=true;triggerButton.textContent="Generando Excel...";}
  try{
    toast("Preparando reporte completo en Excel...");
    const [insQ,comQ,workQ,conQ,infQ,profQ,planQ]=await Promise.all([
      supabase.from("inspections").select("id,inspected_at,status,target_type,act_number,regularization_deadline,finalized_at,latitude,longitude,gps_accuracy_m,qr_scanned,observations,commerces(business_name,address),works(responsible,address,file_number),profiles!inspections_inspector_id_fkey(full_name,email)").order("inspected_at",{ascending:false}),
      supabase.from("commerces").select("*").order("business_name"),
      supabase.from("works").select("*").order("responsible"),
      supabase.from("contributors").select("*").order("name"),
      supabase.from("infractions").select("*").order("infraction_date",{ascending:false}),
      supabase.from("profiles").select("id,full_name,email,role,active,created_at,photo_path").eq("role","inspector").order("full_name"),
      supabase.from("inspection_plan_items").select("id,status,source_row,completed_at,completed_by_name,completed_inspection_id,commerces(business_name,cuit,address,sector,zone,commercial_license),commerce_import_batches(file_name,uploaded_at)").order("created_at",{ascending:false})
    ]);
    const queries=[insQ,comQ,workQ,conQ,infQ,profQ,planQ];
    const failed=queries.find(q=>q.error);if(failed?.error)throw failed.error;
    const ins=insQ.data||[],com=comQ.data||[],wor=workQ.data||[],con=conQ.data||[],inf=infQ.data||[],pro=profQ.data||[],plan=planQ.data||[];
    const countBy=(arr,key)=>arr.reduce((a,x)=>{const k=x[key]||"Sin dato";a[k]=(a[k]||0)+1;return a},{});
    const inspectionsByStatus=countBy(ins,"status");
    const commercesBySector=countBy(com,"sector");
    const worksByStatus=countBy(wor,"status");
    const monthMap={};
    [...ins].sort((a,b)=>new Date(a.inspected_at)-new Date(b.inspected_at)).forEach(i=>{const d=new Date(i.inspected_at);if(Number.isNaN(d.getTime()))return;const key=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}`;if(!monthMap[key])monthMap[key]={label:d.toLocaleDateString("es-AR",{month:"short",year:"numeric"}),count:0};monthMap[key].count++;});
    const inspectionsByMonth=Object.fromEntries(Object.values(monthMap).map(x=>[x.label,x.count]));

    const wb=new window.ExcelJS.Workbook();
    wb.creator="SIMA 360°";wb.lastModifiedBy="SIMA 360°";wb.created=new Date();wb.modified=new Date();wb.subject="Reporte municipal integral";wb.title="SIMA 360° - Reportes e indicadores";
    const summary=wb.addWorksheet("Resumen",{views:[{state:"frozen",ySplit:4}]});
    for(let c=1;c<=16;c++)summary.getColumn(c).width=12;
    summary.mergeCells("A1:P2");const sc=summary.getCell("A1");sc.value="SIMA 360° · Reporte Municipal Integral";sc.font={bold:true,size:24,color:{argb:"FFFFFFFF"}};sc.fill={type:"pattern",pattern:"solid",fgColor:{argb:"FF102C49"}};sc.alignment={vertical:"middle",horizontal:"center"};
    summary.mergeCells("A3:P3");summary.getCell("A3").value=`Generado: ${new Date().toLocaleString("es-AR")} · Usuario: ${profile?.full_name||"Administrador"}`;summary.getCell("A3").font={italic:true,color:{argb:"FF667085"}};summary.getCell("A3").alignment={horizontal:"center"};
    const kpis=[
      ["Comercios",com.length,"FF1597E5"],["Obras privadas",wor.length,"FFF59E0B"],["Inspecciones",ins.length,"FF19A66A"],
      ["Contribuyentes",con.length,"FF8B5CF6"],["Infracciones abiertas",inf.filter(x=>x.status==="abierta").length,"FFDC2626"],["Inspectores activos",pro.filter(x=>x.active).length,"FF0891B2"]
    ];
    kpis.forEach((k,i)=>{const row=5+Math.floor(i/3)*3,col=1+(i%3)*5;summary.mergeCells(row,col,row,col+3);summary.getCell(row,col).value=k[0];summary.getCell(row,col).font={bold:true,color:{argb:"FFFFFFFF"}};summary.getCell(row,col).fill={type:"pattern",pattern:"solid",fgColor:{argb:k[2]}};summary.getCell(row,col).alignment={horizontal:"center"};summary.mergeCells(row+1,col,row+1,col+3);summary.getCell(row+1,col).value=k[1];summary.getCell(row+1,col).font={bold:true,size:22,color:{argb:"FF101828"}};summary.getCell(row+1,col).alignment={horizontal:"center"};});

    const chartSpecs=[
      ["Estado de inspecciones",inspectionsByStatus,"#19a66a",0,12],
      ["Inspecciones por período",inspectionsByMonth,"#1597e5",8,12],
      ["Comercios por rubro",commercesBySector,"#8b5cf6",0,31],
      ["Obras por estado",worksByStatus,"#f59e0b",8,31]
    ];
    chartSpecs.forEach(([title,obj,color,col,row])=>{const img=wb.addImage({base64:makeBarChartImage(title,obj,color),extension:"png"});summary.addImage(img,{tl:{col,row},ext:{width:560,height:285}});});

    const graphRows=(obj)=>Object.entries(obj).map(([k,v])=>[excelStatusLabel(k),v]);
    addExcelDataSheet(wb,"Graf Inspecciones","Datos del gráfico · Estado de inspecciones",["Estado","Cantidad"],graphRows(inspectionsByStatus),"FF19A66A",[28,14]);
    addExcelDataSheet(wb,"Graf Periodos","Datos del gráfico · Inspecciones por período",["Período","Cantidad"],graphRows(inspectionsByMonth),"FF1597E5",[22,14]);
    addExcelDataSheet(wb,"Graf Comercios","Datos del gráfico · Comercios por rubro",["Rubro","Cantidad"],graphRows(commercesBySector),"FF8B5CF6",[30,14]);
    addExcelDataSheet(wb,"Graf Obras","Datos del gráfico · Obras por estado",["Estado","Cantidad"],graphRows(worksByStatus),"FFF59E0B",[28,14]);

    addExcelDataSheet(wb,"Inspecciones","Listado completo de inspecciones",
      ["ID","Fecha y hora","N° de Expediente","Tipo","Estado","Comercio / Obra","Dirección","Inspector","Correo inspector","Plazo regularización","Finalizada","QR escaneado","Latitud","Longitud","Precisión GPS (m)","Observaciones"],
      ins.map(i=>[excelSafe(i.id),fmtDate(i.inspected_at),excelSafe(i.act_number),excelStatusLabel(i.target_type),excelStatusLabel(i.status),excelSafe(i.commerces?.business_name||i.works?.responsible),excelSafe(i.commerces?.address||i.works?.address),excelSafe(i.profiles?.full_name),excelSafe(i.profiles?.email),i.regularization_deadline?fmtDay(i.regularization_deadline):"",i.finalized_at?fmtDate(i.finalized_at):"",i.qr_scanned?"Sí":"No",excelSafe(i.latitude),excelSafe(i.longitude),excelSafe(i.gps_accuracy_m),excelSafe(i.observations)]),"FF19A66A",[38,20,18,16,18,32,34,28,30,20,20,14,14,14,16,42]);

    addExcelDataSheet(wb,"Comercios","Base de datos de comercios",
      ["ID","Nombre comercial","Razón social","CUIT","N° habilitación","Dirección","Ciudad","Provincia","Rubro","Zona","Teléfono","Correo","Vencimiento habilitación","Estado","Activo","Observaciones"],
      com.map(c=>[excelSafe(c.id),excelSafe(c.business_name),excelSafe(c.legal_name),excelSafe(c.cuit),excelSafe(c.commercial_license),excelSafe(c.address),excelSafe(c.city),excelSafe(c.province),excelSafe(c.sector),excelSafe(c.zone),excelSafe(c.phone),excelSafe(c.email),c.license_expiration?fmtDay(c.license_expiration):"",excelStatusLabel(c.status),c.active?"Sí":"No",excelSafe(c.observations)]),"FF1597E5",[38,28,28,18,18,34,18,18,24,18,18,30,22,16,12,42]);

    addExcelDataSheet(wb,"Obras","Base de datos de obras privadas",
      ["ID","Responsable","DNI / CUIT","Dirección","Ciudad","Provincia","Zona","N° expediente","Descripción","Estado","Inicio","Fin estimado","Observaciones"],
      wor.map(w=>[excelSafe(w.id),excelSafe(w.responsible),excelSafe(w.dni_cuit),excelSafe(w.address),excelSafe(w.city),excelSafe(w.province),excelSafe(w.zone),excelSafe(w.file_number),excelSafe(w.description),excelStatusLabel(w.status),w.start_date?fmtDay(w.start_date):"",w.estimated_end_date?fmtDay(w.estimated_end_date):"",excelSafe(w.observations)]),"FFF59E0B",[38,28,18,34,18,18,18,18,40,20,16,18,42]);

    addExcelDataSheet(wb,"Contribuyentes","Base de datos de contribuyentes",
      ["ID","Tipo","Nombre / Razón social","DNI / CUIT","Teléfono","Correo","Dirección","Zona","Actividad","Estado","Alta"],
      con.map(c=>[excelSafe(c.id),excelStatusLabel(c.contributor_type),excelSafe(c.name),excelSafe(c.dni_cuit),excelSafe(c.phone),excelSafe(c.email),excelSafe(c.address),excelSafe(c.zone),excelSafe(c.activity),excelStatusLabel(c.status),fmtDate(c.created_at)]),"FF8B5CF6",[38,16,32,20,18,30,34,18,28,16,20]);

    addExcelDataSheet(wb,"Infracciones","Registro de infracciones",
      ["ID","Código","Fecha","Inspección ID","Motivo","Normativa","Estado","Plazo regularización","Observaciones","Alta"],
      inf.map(x=>[excelSafe(x.id),excelSafe(x.code),x.infraction_date?fmtDay(x.infraction_date):"",excelSafe(x.inspection_id),excelSafe(x.reason),excelSafe(x.regulation),excelStatusLabel(x.status),x.regularization_deadline?fmtDay(x.regularization_deadline):"",excelSafe(x.observations),fmtDate(x.created_at)]),"FFDC2626",[38,18,16,38,40,30,18,20,42,20]);

    addExcelDataSheet(wb,"Inspectores","Usuarios inspectores",
      ["ID","Nombre y apellido","Correo","Estado","Fecha de alta","Foto cargada"],
      pro.map(p=>[excelSafe(p.id),excelSafe(p.full_name),excelSafe(p.email),p.active?"Activo":"Inactivo",fmtDate(p.created_at),p.photo_path?"Sí":"No"]),"FF0891B2",[38,30,32,16,22,16]);

    addExcelDataSheet(wb,"Planilla inspecciones","Seguimiento de planillas importadas de comerciantes",
      ["Planilla","Fecha de carga","Fila origen","Comercio","CUIT","Rubro","Zona","Dirección","Habilitación","Estado","Inspector","Fecha inspección","Inspección ID"],
      plan.map(x=>[excelSafe(x.commerce_import_batches?.file_name),x.commerce_import_batches?.uploaded_at?fmtDate(x.commerce_import_batches.uploaded_at):"",excelSafe(x.source_row),excelSafe(x.commerces?.business_name),excelSafe(x.commerces?.cuit),excelSafe(x.commerces?.sector),excelSafe(x.commerces?.zone),excelSafe(x.commerces?.address),excelSafe(x.commerces?.commercial_license),x.status==="inspeccionado"?"Inspeccionado":"Pendiente",excelSafe(x.completed_by_name),x.completed_at?fmtDate(x.completed_at):"",excelSafe(x.completed_inspection_id)]),"FF2563EB",[32,20,12,30,18,22,18,34,18,18,28,22,38]);

    const buffer=await wb.xlsx.writeBuffer();
    const blob=new Blob([buffer],{type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"});
    const url=URL.createObjectURL(blob);const a=document.createElement("a");const d=new Date();const date=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;a.href=url;a.download=`SIMA-360-Reporte-Municipal-${date}.xlsx`;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);
    toast("Excel completo generado correctamente.");
  }catch(err){console.error(err);toast(`No se pudo generar el Excel: ${err?.message||err}`,"error");}
  finally{if(triggerButton){triggerButton.disabled=false;triggerButton.textContent=oldText||"Descargar Excel";}}
}

function wireExcelButton(id){const b=field(id);if(b)b.onclick=()=>exportMunicipalExcel(b);}

async function reportsView(){
  loading("Calculando reportes...");
  const [{data:inspections},{data:commerces},{data:works}]=await Promise.all([supabase.from("inspections").select("status,inspected_at,target_type"),supabase.from("commerces").select("sector,status"),supabase.from("works").select("status")]);
  const ins=inspections||[], com=commerces||[], wor=works||[];
  const countBy=(arr,key)=>arr.reduce((a,x)=>{const k=x[key]||"Sin dato";a[k]=(a[k]||0)+1;return a},{});
  const bars=obj=>{const max=Math.max(1,...Object.values(obj));return Object.entries(obj).sort((a,b)=>b[1]-a[1]).map(([k,v])=>`<div class="bar-row"><span>${esc(k.replaceAll("_"," "))}</span><div class="bar-track"><div class="bar-fill" style="width:${Math.round(v/max*100)}%"></div></div><b>${v}</b></div>`).join("")||`<div class="notice">Sin datos todavía.</div>`};
  const monthMap={};[...ins].sort((a,b)=>new Date(a.inspected_at)-new Date(b.inspected_at)).forEach(i=>{const d=new Date(i.inspected_at);if(Number.isNaN(d.getTime()))return;const key=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}`;if(!monthMap[key])monthMap[key]={label:d.toLocaleDateString("es-AR",{month:"short",year:"numeric"}),count:0};monthMap[key].count++;});
  const months=Object.fromEntries(Object.values(monthMap).map(x=>[x.label,x.count]));
  shell(`${pageTitle("Reportes y estadísticas","Datos que se convierten en mejores decisiones.",`<button class="primary excel-export-btn" id="exportReportsExcel" type="button">⬇ Descargar Excel completo</button>`)}<div class="export-note"><b>Excel de presentación:</b> incluye indicadores, gráficos, datos de inspecciones, comercios, obras, contribuyentes, infracciones e inspectores en hojas separadas.</div><div class="report-grid"><div class="panel"><h3>Estado de inspecciones</h3>${bars(countBy(ins,"status"))}</div><div class="panel"><h3>Inspecciones por período</h3>${bars(months)}</div><div class="panel"><h3>Comercios por rubro</h3>${bars(countBy(com,"sector"))}</div><div class="panel"><h3>Obras por estado</h3>${bars(countBy(wor,"status"))}</div></div>`);
  wireExcelButton("exportReportsExcel");
}


function normalizeImportHeader(value=""){
  return String(value??"").trim().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[°º]/g,"").replace(/[^a-z0-9]+/g," ").trim();
}

function excelCellValue(v){
  if(v==null)return "";
  if(v instanceof Date)return v;
  if(typeof v==="object"){
    if(v.text!=null)return String(v.text);
    if(v.result!=null)return v.result;
    if(Array.isArray(v.richText))return v.richText.map(x=>x.text||"").join("");
  }
  return v;
}

function excelDateISO(v){
  if(!v)return null;
  if(v instanceof Date && !Number.isNaN(v.getTime())){
    const y=v.getFullYear(),m=String(v.getMonth()+1).padStart(2,"0"),d=String(v.getDate()).padStart(2,"0");
    return `${y}-${m}-${d}`;
  }
  const s=String(v).trim();
  if(!s)return null;
  const dmy=s.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})$/);
  if(dmy){
    let y=dmy[3]; if(y.length===2)y=`20${y}`;
    return `${y}-${dmy[2].padStart(2,"0")}-${dmy[1].padStart(2,"0")}`;
  }
  const iso=s.match(/^(\d{4})-(\d{2})-(\d{2})/);
  return iso?`${iso[1]}-${iso[2]}-${iso[3]}`:null;
}

const normalizeMatch = v => normalizeImportHeader(v).replace(/\s+/g," ");

function findImportColumn(headers, aliases){
  for(const a of aliases){
    const needle=normalizeMatch(a);
    const idx=headers.findIndex(h=>h===needle);
    if(idx>=0)return idx;
  }
  return -1;
}

function downloadCommerceImportTemplate(){
  if(!window.ExcelJS)return toast("No se pudo cargar el componente de Excel.","error");
  const wb=new ExcelJS.Workbook();
  const ws=wb.addWorksheet("Comercios");
  const headers=["Comercio","Razón social","CUIT","Dirección","Rubro","Zona","N° Habilitación","Teléfono","Correo","Vencimiento habilitación","Observaciones"];
  ws.addRow(headers);
  ws.getRow(1).font={bold:true,color:{argb:"FFFFFFFF"}};
  ws.getRow(1).fill={type:"pattern",pattern:"solid",fgColor:{argb:"FF12365B"}};
  ws.columns=[24,28,18,30,22,18,18,18,28,24,36].map(width=>({width}));
  const ex=wb.addWorksheet("Ejemplo");ex.addRow(headers);ex.addRow(["Panadería Ejemplo","Panadería Ejemplo SRL","30-12345678-9","San Martín 123","Panadería","Centro","HAB-001","3756-000000","ejemplo@correo.com","31/12/2026","Ejemplo de carga"]);ex.getRow(1).font={bold:true,color:{argb:"FFFFFFFF"}};ex.getRow(1).fill={type:"pattern",pattern:"solid",fgColor:{argb:"FF12365B"}};ex.columns=[24,28,18,30,22,18,18,18,28,24,36].map(width=>({width}));
  wb.xlsx.writeBuffer().then(buffer=>{
    const blob=new Blob([buffer],{type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"});
    const url=URL.createObjectURL(blob),a=document.createElement("a");
    a.href=url;a.download="Plantilla-Comercios-SIMA-360.xlsx";document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
  });
}

async function importCommerceExcel(file,button){
  if(profile?.role!=="admin")return toast("Solo el Administrador puede importar la planilla.","error");
  if(!file)return toast("Seleccioná un archivo Excel.","error");
  if(!window.XLSX)return toast("No se pudo cargar el lector de Excel. Cerrá y volvé a abrir SIMA 360° e intentá nuevamente.","error");

  const old=button?.textContent||"Importar Excel";
  if(button){button.disabled=true;button.textContent="Leyendo archivo...";}

  try{
    const buffer=await file.arrayBuffer();
    const wb=XLSX.read(buffer,{type:"array",cellDates:true,raw:false});
    const sheetName=wb.SheetNames?.[0];
    if(!sheetName)throw new Error("El archivo no contiene ninguna hoja.");
    const ws=wb.Sheets[sheetName];
    const matrix=XLSX.utils.sheet_to_json(ws,{header:1,defval:"",raw:false,blankrows:false});
    if(!matrix.length)throw new Error("La primera hoja está vacía.");

    // Busca automáticamente la fila de encabezados, aunque el Excel tenga un título arriba.
    const knownHeaders=[
      "comercio","nombre comercial","nombre comercio","establecimiento","local","razon social",
      "cuit","cuil","dni","direccion","domicilio","domicilio comercial","rubro","actividad",
      "zona","barrio","habilitacion","numero habilitacion","n habilitacion",
      "telefono","celular","correo","email","vencimiento","observaciones"
    ].map(normalizeMatch);

    let headerRowIndex=-1,bestScore=-1;
    for(let r=0;r<Math.min(matrix.length,25);r++){
      const row=(matrix[r]||[]).map(v=>normalizeMatch(v));
      let score=0;
      for(const cell of row){
        if(!cell)continue;
        if(knownHeaders.some(h=>cell===h||cell.includes(h)||h.includes(cell)))score++;
      }
      if(score>bestScore){bestScore=score;headerRowIndex=r;}
    }
    if(headerRowIndex<0||bestScore<2){
      throw new Error('No pude identificar la fila de encabezados. Probá con la plantilla de SIMA 360° o enviame una captura de los nombres de las columnas.');
    }

    const rawHeaders=matrix[headerRowIndex]||[];
    const headers=rawHeaders.map(normalizeMatch);

    const fuzzyColumn=(aliases)=>{
      const normalized=aliases.map(normalizeMatch);
      let idx=headers.findIndex(h=>normalized.includes(h));
      if(idx>=0)return idx;
      idx=headers.findIndex(h=>h&&normalized.some(a=>h.includes(a)||a.includes(h)));
      return idx;
    };

    const col={
      business:fuzzyColumn(["comercio","nombre comercial","nombre comercio","establecimiento","local","nombre del comercio","nombre fantasia","nombre de fantasia","razon social","razón social"]),
      owner:fuzzyColumn(["nombre y apellido","nombre apellido","titular","propietario","responsable","comerciante"]),
      cuit:fuzzyColumn(["cuit","cuil","cuit cuil","dni cuit","dni/cuit","documento"]),
      address:fuzzyColumn(["direccion","dirección","domicilio","domicilio comercial","direccion comercial","dirección comercial"]),
      sector:fuzzyColumn(["rubro","actividad","sector","actividad comercial"]),
      zone:fuzzyColumn(["zona","barrio","sector zona"]),
      license:fuzzyColumn(["n habilitacion","n° habilitacion","numero habilitacion","nro habilitacion","habilitacion","licencia"]),
      phone:fuzzyColumn(["telefono","teléfono","celular","telefono celular","contacto"]),
      email:fuzzyColumn(["correo","correo electronico","correo electrónico","email","e mail"]),
      expiry:fuzzyColumn(["vencimiento habilitacion","vencimiento","fecha vencimiento","vence habilitacion","vence"]),
      obs:fuzzyColumn(["observaciones","observacion","observación","notas"])
    };

    // El archivo municipal que recibiste usa "Nombre y Apellido" para el titular
    // y "Razón social" para el nombre/actividad comercial. Además, la columna
    // "Zona" contiene en la práctica el domicilio. SIMA lo detecta automáticamente.
    if(col.business<0 && col.owner<0){
      throw new Error('No encontré el nombre del comercio ni el titular. En tu planilla puede estar como "Razón social" o "Nombre y Apellido".');
    }
    const zoneIsAddress = col.address < 0 && col.zone >= 0;

    const rows=[];
    let skipped=0;
    const get=(row,idx)=>idx<0?"":(row?.[idx]??"");

    for(let r=headerRowIndex+1;r<matrix.length;r++){
      const row=matrix[r]||[];
      const commercialName=String(get(row,col.business)||"").trim();
      const ownerName=String(get(row,col.owner)||"").trim();
      const business=commercialName||ownerName;
      const zoneValue=String(get(row,col.zone)||"").trim();
      const addressRaw=String(get(row,col.address)||"").trim() || (zoneIsAddress ? zoneValue : "");

      // Ignora filas totalmente vacías o totales/pies de página.
      const hasAny=row.some(v=>String(v??"").trim()!=="");
      if(!hasAny)continue;
      if(!business){skipped++;continue;}

      const raw={};
      rawHeaders.forEach((h,i)=>{
        const key=String(h??"").trim();
        if(key)raw[key]=String(row[i]??"").trim();
      });

      rows.push({
        sourceRow:r+1,
        business_name:business,
        // En tu archivo, "Nombre y Apellido" identifica al titular/responsable.
        legal_name:ownerName||null,
        cuit:String(get(row,col.cuit)||"").trim()||null,
        address:addressRaw||"Sin especificar",
        sector:String(get(row,col.sector)||"").trim()||null,
        // Si "Zona" fue usada como domicilio, no la repetimos como zona.
        zone:zoneIsAddress ? null : (zoneValue||null),
        commercial_license:String(get(row,col.license)||"").trim()||null,
        phone:String(get(row,col.phone)||"").trim()||null,
        email:String(get(row,col.email)||"").trim()||null,
        license_expiration:excelDateISO(get(row,col.expiry)),
        observations:String(get(row,col.obs)||"").trim()||null,
        raw
      });
    }

    if(!rows.length)throw new Error("No encontré comercios válidos debajo de la fila de encabezados.");

    if(button)button.textContent="Importando comercios...";

    const {data:batch,error:batchErr}=await supabase.from("commerce_import_batches").insert({
      file_name:file.name,
      uploaded_by:session.user.id,
      total_rows:rows.length+skipped,
      skipped_rows:skipped
    }).select().single();
    if(batchErr)throw batchErr;

    const {data:existing,error:existingErr}=await supabase.from("commerces").select("id,business_name,address,cuit").eq("active",true);
    if(existingErr)throw existingErr;

    const byCuit=new Map(),byNameAddr=new Map();
    for(const c of existing||[]){
      if(c.cuit)byCuit.set(normalizeMatch(c.cuit),c.id);
      byNameAddr.set(`${normalizeMatch(c.business_name)}|${normalizeMatch(c.address)}`,c.id);
    }

    const valid=[],seen=new Set(),newRows=[];
    for(const r of rows){
      const cuitKey=r.cuit?normalizeMatch(r.cuit):"";
      const naKey=`${normalizeMatch(r.business_name)}|${normalizeMatch(r.address)}`;
      const rowKey=cuitKey?`c:${cuitKey}`:`n:${naKey}`;
      if(seen.has(rowKey)){skipped++;continue;}
      seen.add(rowKey);
      const existingId=(cuitKey&&byCuit.get(cuitKey))||byNameAddr.get(naKey)||null;
      const entry={...r,commerce_id:existingId,rowKey,cuitKey,naKey};
      valid.push(entry);
      if(!existingId)newRows.push(entry);
    }

    let importedNew=0,linkedExisting=valid.length-newRows.length;

    for(let i=0;i<newRows.length;i+=100){
      const chunk=newRows.slice(i,i+100);
      const payload=chunk.map(r=>({
        business_name:r.business_name,
        legal_name:r.legal_name,
        cuit:r.cuit,
        commercial_license:r.commercial_license,
        address:r.address,
        city:"Santo Tomé",
        province:"Corrientes",
        sector:r.sector,
        zone:r.zone,
        phone:r.phone,
        email:r.email,
        license_expiration:r.license_expiration,
        observations:r.observations,
        status:"activo",
        active:true,
        created_by:session.user.id
      }));

      const {data:inserted,error}=await supabase.from("commerces").insert(payload).select("id,business_name,address,cuit");
      if(error)throw error;
      importedNew+=(inserted||[]).length;

      for(const c of inserted||[]){
        if(c.cuit)byCuit.set(normalizeMatch(c.cuit),c.id);
        byNameAddr.set(`${normalizeMatch(c.business_name)}|${normalizeMatch(c.address)}`,c.id);
      }
    }

    if(button)button.textContent="Creando plan de inspección...";

    const planRows=[];
    for(const r of valid){
      const commerceId=r.commerce_id||(r.cuitKey&&byCuit.get(r.cuitKey))||byNameAddr.get(r.naKey);
      if(!commerceId){skipped++;continue;}
      planRows.push({
        batch_id:batch.id,
        commerce_id:commerceId,
        source_row:r.sourceRow,
        source_data:r.raw,
        status:"pendiente"
      });
    }

    for(let i=0;i<planRows.length;i+=150){
      const {error}=await supabase.from("inspection_plan_items").insert(planRows.slice(i,i+150));
      if(error)throw error;
    }

    await supabase.from("commerce_import_batches").update({
      imported_rows:importedNew,
      linked_existing_rows:linkedExisting,
      skipped_rows:skipped,
      total_rows:rows.length+skipped
    }).eq("id",batch.id);

    sessionStorage.setItem("sima_plan_batch",batch.id);
    toast(`Excel importado correctamente: ${planRows.length} comercios disponibles para inspeccionar.`);
    route="planilla";
    render();
  }catch(err){
    console.error("Error importando Excel:",err);
    const msg=err?.message||String(err);
    toast(`Error al subir el Excel: ${msg}`,"error");

    // Muestra el error dentro del módulo para que se pueda leer completo.
    const zone=document.getElementById("excelImportError");
    if(zone)zone.innerHTML=`<div class="error"><b>No se pudo importar el archivo.</b><br>${esc(msg)}</div>`;
  }finally{
    if(button){button.disabled=false;button.textContent=old;}
  }
}
async function planillaView(){
  loading("Cargando planilla de comercios...");
  const admin=profile?.role==="admin";
  const {data:batches,error:batchError}=await supabase.from("commerce_import_batches").select("*").order("uploaded_at",{ascending:false});
  if(batchError)return shell(`<div class="error">${esc(batchError.message)}</div>`);
  const list=batches||[];
  let batchId=sessionStorage.getItem("sima_plan_batch")||list[0]?.id||"";
  if(batchId&&!list.some(b=>b.id===batchId))batchId=list[0]?.id||"";

  let items=[];
  if(batchId){
    const {data,error}=await supabase.from("inspection_plan_items")
      .select("id,batch_id,commerce_id,source_row,status,completed_inspection_id,completed_by,completed_by_name,completed_at,commerces(id,business_name,legal_name,cuit,address,sector,zone,commercial_license,phone,email)")
      .eq("batch_id",batchId).order("source_row",{ascending:true});
    if(error)return shell(`<div class="error">${esc(error.message)}</div>`);
    items=data||[];
  }

  const pending=items.filter(x=>x.status!=="inspeccionado").length;
  const done=items.filter(x=>x.status==="inspeccionado").length;
  const selectedBatch=list.find(b=>b.id===batchId);

  const adminTools=admin?`<div class="panel import-panel">
    <div class="panel-head"><h3>Importar planilla Excel</h3><span>Solo Administrador</span></div>
    <p class="small">Podés cargar una planilla recibida con datos de comerciantes. SIMA reconoce las columnas del archivo municipal y evita duplicados cuando puede identificarlos.</p>
    <div id="excelImportError"></div>
    <div class="excel-import-row">
      <input id="commerceExcelFile" type="file" accept=".xlsx,.xls,.xlsm,.csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel,text/csv">
      <button id="importCommerceExcel" class="primary" type="button">Subir e importar Excel</button>
      <button id="downloadCommerceTemplate" class="secondary" type="button">Descargar plantilla</button>
    </div>
  </div>`:"";

  shell(`${pageTitle("Planilla de comercios","Seguimiento de la planilla importada y de las inspecciones realizadas.")}
    ${adminTools}
    <div class="panel plan-toolbar">
      <div class="field plan-batch-field"><label>Planilla / lote</label><select id="planBatchSelect"><option value="">Sin planillas cargadas</option>${list.map(b=>`<option value="${b.id}" ${b.id===batchId?"selected":""}>${esc(b.file_name)} · ${fmtDate(b.uploaded_at)}</option>`).join("")}</select></div>
      ${selectedBatch?`<div class="plan-meta"><b>${esc(selectedBatch.file_name)}</b><span>${selectedBatch.total_rows||0} filas procesadas</span></div>`:""}
    </div>

    <div class="metrics-grid compact plan-metrics">
      ${metric("PL","Total",items.length,"blue")}
      ${metric("PE","Pendientes",pending,"orange")}
      ${metric("OK","Inspeccionados",done,"green")}
    </div>

    <div class="panel plan-list-panel">
      <div class="panel-head"><h3>Comercios de la planilla</h3><span>${done} realizados · ${pending} pendientes</span></div>

      <div class="plan-controls">
        <div class="field plan-search-field">
          <label>Buscar comercio</label>
          <input id="planSearch" type="search" placeholder="Nombre, CUIT, rubro o dirección">
        </div>
        <div class="field plan-filter-field">
          <label>Estado</label>
          <select id="planStatusFilter">
            <option value="todos">Todos</option>
            <option value="pendiente">Pendientes</option>
            <option value="inspeccionado">Inspeccionados</option>
          </select>
        </div>
        <div class="field plan-size-field">
          <label>Mostrar</label>
          <select id="planPageSize">
            <option value="10">10 por página</option>
            <option value="25" selected>25 por página</option>
            <option value="50">50 por página</option>
          </select>
        </div>
      </div>

      <div id="planResultInfo" class="plan-result-info"></div>
      <div class="table-wrap plan-scroll-area">
        <table class="plan-table">
          <thead><tr><th>Comercio</th><th>CUIT</th><th>Rubro / Zona</th><th>Dirección</th><th>Estado</th><th>Inspector</th><th>Fecha</th><th>Acción</th></tr></thead>
          <tbody id="planRows"></tbody>
        </table>
      </div>

      <div class="plan-pagination">
        <button id="planPrev" class="secondary" type="button">← Anterior</button>
        <span id="planPageInfo">Página 1</span>
        <button id="planNext" class="secondary" type="button">Siguiente →</button>
      </div>
    </div>`);

  field("planBatchSelect")?.addEventListener("change",e=>{sessionStorage.setItem("sima_plan_batch",e.target.value);planillaView()});

  if(admin){
    field("downloadCommerceTemplate")?.addEventListener("click",downloadCommerceImportTemplate);
    field("importCommerceExcel")?.addEventListener("click",()=>importCommerceExcel(field("commerceExcelFile")?.files?.[0],field("importCommerceExcel")));
  }

  let page=1;
  let pageSize=25;

  const normalizeSearch=v=>String(v||"").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"");

  const bindPlanActions=()=>{
    document.querySelectorAll("[data-plan-inspect]").forEach(b=>b.onclick=()=>{
      sessionStorage.setItem("selected_target",JSON.stringify({type:"commerce",data:{id:b.dataset.commerceId,business_name:b.dataset.commerceName,address:b.dataset.commerceAddress}}));
      sessionStorage.setItem("selected_plan_item",b.dataset.planInspect);
      sessionStorage.setItem("inspection_return_route","planilla");
      route="nueva-inspeccion";render();
    });
  };

  const renderRows=()=>{
    const q=normalizeSearch(field("planSearch")?.value);
    const status=field("planStatusFilter")?.value||"todos";
    pageSize=parseInt(field("planPageSize")?.value||"25",10);

    const filtered=items.filter(x=>{
      const c=x.commerces||{};
      const haystack=normalizeSearch([c.business_name,c.legal_name,c.cuit,c.sector,c.zone,c.address,c.commercial_license,x.completed_by_name].filter(Boolean).join(" "));
      const matchText=!q||haystack.includes(q);
      const matchStatus=status==="todos"||(status==="inspeccionado"?x.status==="inspeccionado":x.status!=="inspeccionado");
      return matchText&&matchStatus;
    });

    const pages=Math.max(1,Math.ceil(filtered.length/pageSize));
    if(page>pages)page=pages;
    if(page<1)page=1;

    const from=(page-1)*pageSize;
    const visible=filtered.slice(from,from+pageSize);

    field("planRows").innerHTML=visible.map(x=>{
      const c=x.commerces||{};
      const isDone=x.status==="inspeccionado";
      return `<tr class="${isDone?"plan-done":"plan-pending"}">
        <td><b>${esc(c.business_name||"—")}</b><div class="small">${esc(c.commercial_license||"")}</div></td>
        <td>${esc(c.cuit||"—")}</td>
        <td>${esc(c.sector||"—")}<div class="small">${esc(c.zone||"")}</div></td>
        <td>${esc(c.address||"—")}</td>
        <td>${badge(isDone?"Inspeccionado":"Pendiente")}</td>
        <td>${esc(x.completed_by_name|| (isDone?"Registrado":"—"))}</td>
        <td>${x.completed_at?fmtDate(x.completed_at):"—"}</td>
        <td>${!admin&&!isDone?`<button class="primary small-btn" data-plan-inspect="${x.id}" data-commerce-id="${c.id}" data-commerce-name="${esc(c.business_name||"")}" data-commerce-address="${esc(c.address||"")}">Registrar inspección</button>`:isDone?`<span class="plan-ok">✓ Realizada</span>`:`<span class="small">Pendiente</span>`}</td>
      </tr>`;
    }).join("")||emptyRow(8,"No hay comercios que coincidan con la búsqueda.");

    const startCount=filtered.length?from+1:0;
    const endCount=Math.min(from+pageSize,filtered.length);
    field("planResultInfo").textContent=`Mostrando ${startCount}–${endCount} de ${filtered.length} comercios`;
    field("planPageInfo").textContent=`Página ${page} de ${pages}`;
    field("planPrev").disabled=page<=1;
    field("planNext").disabled=page>=pages;
    bindPlanActions();

    // En celular, al cambiar de página vuelve al inicio de la lista, no al principio de toda la pantalla.
    if(window.innerWidth<=760){
      document.querySelector(".plan-list-panel")?.scrollIntoView({block:"start",behavior:"smooth"});
    }
  };

  field("planSearch")?.addEventListener("input",()=>{page=1;renderRows()});
  field("planStatusFilter")?.addEventListener("change",()=>{page=1;renderRows()});
  field("planPageSize")?.addEventListener("change",()=>{page=1;renderRows()});
  field("planPrev")?.addEventListener("click",()=>{if(page>1){page--;renderRows()}});
  field("planNext")?.addEventListener("click",()=>{page++;renderRows()});

  renderRows();
}

async function inspectorHome(){
  const [{count:total},{count:obs}]=await Promise.all([
    supabase.from("inspections").select("id",{count:"exact",head:true}).eq("inspector_id",session.user.id),
    supabase.from("inspections").select("id",{count:"exact",head:true}).eq("inspector_id",session.user.id).eq("status","observada")
  ]);
  await refreshOwnPhoto();
  shell(`${pageTitle(`Hola, ${profile.full_name}`,"Panel operativo de Higiene y Seguridad en el Trabajo.")}
    <div class="inspector-profile-card inspector-profile-view">
      <div class="inspector-avatar inspector-avatar-xl">${profilePhotoUrl?`<img src="${profilePhotoUrl}" alt="Foto de ${esc(profile.full_name)}">`:`<span>${initials(profile.full_name)}</span>`}</div>
      <div class="inspector-profile-info">
        <b>${esc(profile.full_name)}</b>
        <span>Técnico en Higiene y Seguridad en el Trabajo</span>
      </div>
    </div>
    <div class="inspector-actions">
      <button class="big-action plan-action" id="goPlan"><span>PL</span> PLANILLA DE COMERCIOS<small>Ver pendientes y registrar inspecciones</small></button>
      <button class="big-action" id="goScan"><span>QR</span> ESCANEAR QR<small>Identificar comercio u obra</small></button>
      <button class="big-action alt" id="goNew"><span>NI</span> NUEVA INSPECCIÓN<small>Seleccionar manualmente</small></button>
    </div>
    <div class="metrics-grid compact">${metric("MI","Mis inspecciones",total,"green")}${metric("OB","Observadas",obs,"orange")}</div>`);
  field("goPlan").onclick=()=>{route="planilla";render()};
  field("goScan").onclick=()=>{route="escanear";render()};
  field("goNew").onclick=()=>{route="nueva-inspeccion";render()};
}

async function identifyToken(token){
  let q=await supabase.from("commerces").select("id,business_name,address,qr_token").eq("qr_token",token).eq("active",true).maybeSingle();
  if(q.data)return {type:"commerce",data:q.data};
  q=await supabase.from("works").select("id,responsible,address,qr_token,status").eq("qr_token",token).maybeSingle();
  if(q.data)return {type:"work",data:q.data};
  return null;
}

async function scanView(){
  shell(`${pageTitle("Escanear QR","Apuntá la cámara al código del comercio o de la obra.")}<div class="panel scan-box"><div id="reader"></div><div id="scanResult" class="notice top-gap">Esperando código QR...</div></div>`);
  if(!window.Html5Qrcode)return field("scanResult").textContent="El lector QR no pudo cargarse.";
  scanner=new window.Html5Qrcode("reader");
  try{
    await scanner.start({facingMode:"environment"},{fps:10,qrbox:{width:250,height:250}},async decoded=>{
      await scanner.stop();scanner=null;
      let token="";let type="";
      try{const u=new URL(decoded);token=u.searchParams.get("verify")||u.searchParams.get("work")||u.searchParams.get("commerce")||u.searchParams.get("token")||"";type=u.searchParams.get("work")?"work":""}catch{token=decoded.trim()}
      if(!token)return field("scanResult").textContent="QR no reconocido.";
      const found=await identifyToken(token);
      if(!found)return field("scanResult").textContent="No se encontró un registro activo para este QR.";
      sessionStorage.setItem("selected_target",JSON.stringify(found));
      route="nueva-inspeccion";render();
    });
  }catch{field("scanResult").textContent="No se pudo abrir la cámara. Revisá el permiso de cámara o elegí el registro manualmente.";}
}

async function newInspection(){
  let selected=JSON.parse(sessionStorage.getItem("selected_target")||"null");
  const selectedPlanItem=sessionStorage.getItem("selected_plan_item")||"";
  if(!selected && pendingWorkToken){const f=await identifyToken(pendingWorkToken);if(f)selected=f;pendingWorkToken=null}
  if(!selected && pendingCommerceToken){const f=await identifyToken(pendingCommerceToken);if(f)selected=f;pendingCommerceToken=null}
  const [{data:commerces},{data:works}]=await Promise.all([supabase.from("commerces").select("id,business_name,address").eq("active",true).order("business_name"),supabase.from("works").select("id,responsible,address,status").order("responsible")]);
  const selectedType=selected?.type||"commerce";
  shell(`${pageTitle("Nueva inspección","Registrar acta, resultado, ubicación y evidencia fotográfica.")}<div class="panel"><form id="inspectionForm" class="form-grid">
    <div class="field"><label>Tipo de inspección</label><select id="target_type"><option value="commerce" ${selectedType==="commerce"?"selected":""}>Comercio</option><option value="work" ${selectedType==="work"?"selected":""}>Obra privada</option></select></div><div class="field"><label>N° de Expediente</label><input id="act_number" placeholder="Ej.: 1234/2026"></div>
    <div class="field wide" id="commerceWrap"><label>Comercio</label><select id="commerce_id"><option value="">Seleccionar...</option>${(commerces||[]).map(c=>`<option value="${c.id}" ${selected?.type==="commerce"&&selected.data.id===c.id?"selected":""}>${esc(c.business_name)} — ${esc(c.address)}</option>`).join("")}</select></div>
    <div class="field wide" id="workWrap"><label>Obra privada</label><select id="work_id"><option value="">Seleccionar...</option>${(works||[]).map(w=>`<option value="${w.id}" ${selected?.type==="work"&&selected.data.id===w.id?"selected":""}>${esc(w.responsible)} — ${esc(w.address)}</option>`).join("")}</select></div>
    <div class="field"><label>Resultado</label><select id="istatus"><option value="conforme">Conforme</option><option value="observada">Observada</option><option value="pendiente">Pendiente</option><option value="requiere_reinspeccion">Requiere reinspección</option></select></div><div class="field"><label>Plazo de regularización</label><input id="regularization_deadline" type="date"></div>
    <div class="field"><label>Foto del acta / evidencia</label><input id="photo" type="file" accept="image/*" capture="environment"></div><div class="field"><label>Descripción de foto</label><input id="photo_description"></div>
    <div class="field wide"><label>Observaciones</label><textarea id="observations" rows="5"></textarea></div><div class="wide actions"><button class="primary">Guardar inspección</button></div>
  </form></div>`);
  const sync=()=>{const isWork=field("target_type").value==="work";field("workWrap").style.display=isWork?"flex":"none";field("commerceWrap").style.display=isWork?"none":"flex"};field("target_type").onchange=sync;sync();
  field("inspectionForm").onsubmit=async e=>{
    e.preventDefault();const type=val("target_type"),commerce_id=val("commerce_id")||null,work_id=val("work_id")||null;if(type==="commerce"&&!commerce_id)return toast("Seleccioná un comercio.","error");if(type==="work"&&!work_id)return toast("Seleccioná una obra.","error");
    const payload={target_type:type,commerce_id:type==="commerce"?commerce_id:null,work_id:type==="work"?work_id:null,inspector_id:session.user.id,act_number:val("act_number")||null,status:val("istatus"),observations:val("observations")||null,regularization_deadline:val("regularization_deadline")||null,qr_scanned:Boolean(selected)};
    if(navigator.geolocation){try{const p=await new Promise((res,rej)=>navigator.geolocation.getCurrentPosition(res,rej,{enableHighAccuracy:true,timeout:8000}));payload.latitude=p.coords.latitude;payload.longitude=p.coords.longitude;payload.gps_accuracy_m=p.coords.accuracy}catch{}}
    const {data:inspection,error}=await supabase.from("inspections").insert(payload).select().single();if(error)return toast(error.message,"error");
    if(selectedPlanItem&&type==="commerce"){
      const {error:planError}=await supabase.from("inspection_plan_items").update({status:"inspeccionado",completed_inspection_id:inspection.id,completed_by:session.user.id,completed_at:new Date().toISOString()}).eq("id",selectedPlanItem).eq("commerce_id",commerce_id);
      if(planError)toast("La inspección se guardó, pero no se pudo actualizar la planilla: "+planError.message,"error");
    }
    const file=field("photo").files[0];if(file){const ext=(file.name.split(".").pop()||"jpg").toLowerCase();const path=`${session.user.id}/${inspection.id}/evidencia-${Date.now()}.${ext}`;const up=await supabase.storage.from("inspection-photos").upload(path,file,{upsert:false});if(!up.error)await supabase.from("inspection_photos").insert({inspection_id:inspection.id,storage_path:path,photo_type:"acta",uploaded_by:session.user.id,description:val("photo_description")||null});else toast("La inspección se guardó, pero la foto no pudo subirse.","error")}
    sessionStorage.removeItem("selected_target");
    sessionStorage.removeItem("selected_plan_item");
    const returnRoute=sessionStorage.getItem("inspection_return_route")||"";
    sessionStorage.removeItem("inspection_return_route");
    toast("Inspección guardada correctamente.");
    route=returnRoute==="planilla"?"planilla":"mis-inspecciones";
    render();
  };
}

async function myInspections(){
  const {data,error}=await supabase.from("inspections").select("id,inspected_at,status,observations,target_type,act_number,commerces(business_name),works(responsible,address),profiles!inspections_inspector_id_fkey(full_name)").eq("inspector_id",session.user.id).order("inspected_at",{ascending:false});
  shell(`${pageTitle("Mis inspecciones","Historial personal de actuaciones.")}<div class="panel">${error?`<div class="error">${esc(error.message)}</div>`:inspectionTable(data||[])}</div>`);
}

async function renderVerification(token){
  app.innerHTML=`<section class="verify-page"><div class="verify-card"><div class="spinner"></div><h2>Verificando comercio...</h2><p>Consultando el registro oficial de SIMA 360°.</p></div></section>`;
  try{const r=await fetch(`${VERIFY_FUNCTION}?token=${encodeURIComponent(token)}`);const j=await r.json();if(!r.ok||!j.ok)throw new Error();const c=j.data.commerce,i=j.data.last_inspection;app.innerHTML=`<section class="verify-page"><div class="verify-card"><div class="verify-brand">SIMA 360°</div><div class="verify-ok">✓</div><h2>Comercio verificado</h2><p>Registro municipal vigente.</p><div class="kv"><div>Comercio</div><div>${esc(c.business_name)}</div><div>Dirección</div><div>${esc(c.address)}</div><div>Localidad</div><div>${esc(c.city||"Santo Tomé")}, ${esc(c.province||"Corrientes")}</div><div>Estado</div><div>${c.active?"Activo":"Inactivo"}</div><div>Última inspección</div><div>${i?fmtDate(i.inspected_at):"Sin inspecciones registradas"}</div><div>Resultado</div><div>${i?esc(i.status):"—"}</div></div><button class="ghost full" onclick="location.href=location.pathname">Ir al inicio</button></div></section>`}catch{app.innerHTML=`<section class="verify-page"><div class="verify-card"><div class="verify-brand">SIMA 360°</div><div class="verify-ok verify-bad">!</div><h2>No se pudo verificar</h2><p>El código no corresponde a un comercio activo o ya no es válido.</p><button class="ghost full" onclick="location.href=location.pathname">Ir al inicio</button></div></section>`}
}

async function render(){
  if(!session||!profile)return loginView();
  if(profile.role==="admin"){
    if(route==="dashboard")return dashboard();if(route==="comercios")return commercesView();if(route==="obras")return worksView();if(route==="inspecciones")return inspectionsView();if(route==="contribuyentes")return contributorsView();if(route==="infracciones")return infractionsView();if(route==="inspectores")return inspectorsView();if(route==="planilla")return planillaView();if(route==="reportes")return reportsView();route="dashboard";return dashboard();
  }
  if(route==="inspector-home")return inspectorHome();if(route==="planilla")return planillaView();if(route==="escanear")return scanView();if(route==="nueva-inspeccion")return newInspection();if(route==="mis-inspecciones")return myInspections();route="inspector-home";return inspectorHome();
}

supabase.auth.onAuthStateChange((event,newSession)=>{session=newSession;if(event==="PASSWORD_RECOVERY"){authRecovery=true;recoveryView();}});
if ("serviceWorker" in navigator) {
  window.addEventListener("load",async()=>{
    try{
      const reg=await navigator.serviceWorker.register("./service-worker.js?v=6.9");
      await reg.update();
    }catch{}
  });
}

init();
