# SIMA 360°

Sistema Integral Municipal de Autogestión, Prevención y Control Inteligente.

Aplicación web municipal conectada a Supabase para gestión de comercios, obras, inspecciones, contribuyentes, infracciones, inspectores, importación de planillas Excel y reportes.

## Despliegue
Sitio de producción: Netlify `control-inspecciones`.

## Versión
Base cargada en GitHub: SIMA 360° v7.3.
